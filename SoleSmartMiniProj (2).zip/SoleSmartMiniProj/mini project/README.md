# Bootstrap 5 UI Internship Task – Reflection Report

## Project Steps
1. Explored Bootstrap 5 documentation and examples.
2. Selected and remixed components: Navbar, Hero/Carousel, Cards, Footer, Contact Form, Accordion.
3. Built three responsive pages: Home, About, Contact.
4. Used Bootstrap 5 via CDN for fast setup.
5. Ensured consistent design and responsiveness.
6. Hosted project on GitHub.

## Tools & Resources Used
- Bootstrap 5 documentation and examples
- GitHub for version control and hosting
- AI assistance (GitHub Copilot) for scaffolding starter code

## Challenges & Solutions
- **Challenge:** Making components look original, not copied.
  - **Solution:** Remixed layouts, changed colors, and customized content.
- **Challenge:** Ensuring mobile responsiveness.
  - **Solution:** Used Bootstrap grid and utility classes, tested on different devices.

## Learning Journey
- Learned how to combine Bootstrap components creatively.
- Improved understanding of responsive design and UI composition.
- Practiced clean code and documentation.

## Time Taken
- Total: 30 minutes(spread over 1 day)

## Transparency
- Used Bootstrap docs and AI tools for guidance and code generation.
- All code is original and remixed, not copy-pasted from examples.

---
