# --- app.py ---

# --- Essential Imports ---
import streamlit as st
import tensorflow as tf
import numpy as np
from PIL import Image # Use Pillow for image handling
import os # For path handling and listing files
# import matplotlib.pyplot as plt # Matplotlib might not be needed for simple image display in Streamlit


# --- Configuration ---
# Define image parameters - Must match what you used during training in Colab!
img_height = 128
img_width = 128
# Define your class names - Must match the order from your training data generators in Colab!
class_names_arch = ['flat', 'high', 'normal'] # Update if your class names/order are different


# Define the path to your trained Arch Type model file relative to app.py
# **CRITICAL: MAKE SURE THIS PATH IS CORRECT**
# - Downloaded 'foot_arch_classifier_model.keras' from Colab?
# - Is it in the SAME directory as your app.py file?
# If yes, this path is correct:
model_arch_type_save_path = "foot_arch_classifier_model.keras"
# If it's in a subdirectory (e.g., 'models'):
# model_arch_type_save_path = "models/foot_arch_classifier_model.keras"


# Define the base path to your recommended images dataset relative to app.py
# This should be the folder that CONTAINS your 'flat footwear', 'normal footwear', etc., folders.
# **CRITICAL: VERIFY THIS EXACT FOLDER NAME AND ITS LOCATION ON YOUR LOCAL DISK**
# - Use your file explorer to check the exact name.
# - Use 'python -c "import os; print(os.listdir('.'))"' in your terminal from the app.py directory to confirm the name as seen by Python.
# - The name in the quotes below MUST EXACTLY match that folder name.
base_recommended_images_path = "recommended footwear images" # <-- **VERIFY & UPDATE THIS STRING**

# If the folder is in a subdirectory (e.g., 'data'):
# base_recommended_images_path = "data/recommended footwear images"


# --- Mapping Dictionaries (Defined at top level for Streamlit reruns) ---

# Map predicted/perceived arch type (lowercase) to the correct FIRST LEVEL dictionary key (e.g., 'flat' -> 'flat footwear')
# This mapping must match the top-level keys in your recommended_image_folders dictionary
first_level_dict_key_map = {
    'flat': 'flat footwear', # Example: map 'flat' arch to 'flat footwear' dictionary key
    'normal': 'normal footwear', # Example mapping
    'high': 'high arch footwear' # Example mapping
    # Add other arch types if needed
}

# Map dropdown display names (lowercase) to a standard internal category key (lowercase) for Image Analysis and General Use
standard_category_map = {
    'shoes': 'shoes',
    'sandal/slipper': 'sandal/slipper',
    'formal shoes': 'formal shoes'
}

# Map the (first_level_dict_key, standard_category_key) tuple to the ACTUAL SECOND LEVEL Dictionary Key
# This is used in the Image Analysis section.
# **Ensure this mapping matches the ACTUAL keys in your recommended_image_folders dictionary's second level**
specific_dictionary_key_map_image_analysis = {
     ('flat footwear', 'shoes'): 'shoes', # Map ('flat footwear', 'shoes') to the actual key 'shoes'
     ('flat footwear', 'sandal/slipper'): 'sandal/slipper', # Map ('flat footwear', 'sandal/slipper') to the actual key 'sandal/slipper'
     ('flat footwear', 'formal shoes'): 'formal shoes', # Map ('flat footwear', 'formal shoes') to the actual key 'formal shoes'

     ('normal footwear', 'shoes'): 'shoes',
     ('normal footwear', 'sandal/slipper'): 'sandal/slipper',
     ('normal footwear', 'formal shoes'): 'formal shoes',

     ('high arch footwear', 'shoes'): 'shoes',
     ('high arch footwear', 'sandal/slipper'): 'sandal/slipper',
     ('high arch footwear', 'formal shoes'): 'formal shoes',
     # Add mappings for any other combinations based on your actual dictionary keys
}


# --- Model Loading ---
# Use st.cache_resource to load the model only once when the app starts
@st.cache_resource
def load_arch_model(model_path):
    model = None
    if os.path.exists(model_path):
        try:
            model = tf.keras.models.load_model(model_path)
            st.sidebar.success("Foot Arch Type Model loaded!") # Use sidebar for less intrusive message
        except Exception as e:
            st.sidebar.error(f"Error loading Foot Arch Type Model from {model_path}: {e}") # Use sidebar
    else:
        st.sidebar.error(f"Foot Arch Type Model file not found at {model_path}. Please check the path in app.py and ensure the file is in your project directory.") # Use sidebar
    return model

# Load the Arch Type model
loaded_model_arch_type = load_arch_model(model_arch_type_save_path)


# --- Prepare Recommended Images Data (Adapted from Colab Step 8) ---
# This dictionary maps arch types (lowercase) and friendly category names (lowercase)
# to the exact folder paths on disk relative to base_recommended_images_path.
# **CRITICAL: UPDATE THE os.path.join CALLS below to match your ACTUAL folder names and structure**
# These paths should match the folders *inside* the folder specified by base_recommended_images_path.

recommended_image_folders = {}
# Check if the base path exists before trying to build the dictionary paths
if base_recommended_images_path and os.path.exists(base_recommended_images_path):
    recommended_image_folders = {
        # **UPDATE THESE TOP-LEVEL KEYS to EXACTLY match the folder names directly inside base_recommended_images_path**
        'flat footwear': { # Example key - VERIFY this matches the folder name inside base_recommended_images_path
            # **UPDATE THESE SECOND-LEVEL KEYS AND STRINGS TO EXACTLY match the folder names inside the 'flat footwear' folder**
            'shoes': os.path.join(base_recommended_images_path, 'flat footwear', 'flatfoot_recommended_shoes'), # VERIFY 'flat footwear' and 'flatfoot_recommended_shoes' match local folder names
            'sandal/slipper': os.path.join(base_recommended_images_path, 'flat footwear', 'flatfoot_recommended_slippers'), # VERIFY folder names
            'formal shoes': os.path.join(base_recommended_images_path, 'flat footwear', 'flatfoot_recommended_formalshoes'), # VERIFY folder names
            # Add other categories if you have them, VERIFY folder names
        },
        'normal footwear': { # Example key - VERIFY this matches the folder name
            'shoes': os.path.join(base_recommended_images_path, 'normal footwear', 'normal_shoes'), # VERIFY folder names
            'sandal/slipper': os.path.join(base_recommended_images_path, 'normal footwear', 'normal_slipper_sandals'), # VERIFY folder names
            'formal shoes': os.path.join(base_recommended_images_path, 'normal footwear', 'normal_formal_shoes'), # VERIFY folder names
            # Add other categories, VERIFY folder names
        },
        'high arch footwear': { # Example key - VERIFY this matches the folder name
            'shoes': os.path.join(base_recommended_images_path, 'high arch footwear', 'higharch_recommended_shoes'), # VERIFY folder names
            'sandal/slipper': os.path.join(base_recommended_images_path, 'high arch footwear', 'higharch_recommended_slipper'), # VERIFY folder names
            'formal shoes': os.path.join(base_recommended_images_path, 'high arch footwear', 'higharch_recommended_formalshoes'), # **CORRECTED TYPO HERE** higharch_recommended_formalshoess -> higharch_recommended_formalshoes
            # Add other categories, VERIFY folder names
        }
        # Add other top-level arch type keys if you have them, VERIFY folder names
    }
    # Optional check after building the dictionary
    # recommended_folders_found_local = True
    # for arch_key, categories in recommended_image_folders.items():
    #     for category_key, path in categories.items():
    #          if not os.path.exists(path):
    #               st.warning(f"Recommended image folder defined but not found locally: {path}")
    #               recommended_folders_found_local = False
    # if recommended_folders_found_local:
    #      st.sidebar.success("All defined recommended image folders exist locally.") # Use sidebar


elif base_recommended_images_path:
     st.error(f"Base recommended images path not found at {base_recommended_images_path}. Please check the path in app.py and ensure the folder exists in your project directory.")
     recommended_image_folders = {} # Ensure dictionary is empty if base path is missing
else:
     st.error("base_recommended_images_path is not set correctly in app.py.")
     recommended_image_folders = {}


# Helper function to get image paths from a specific recommendation folder (Adapted from Colab)
@st.cache_data # Cache the results of listing files in a folder
def get_recommended_image_paths(arch_type_dict_key, footwear_category_dict_key, rec_image_folders_dict):
    """
    Retrieves a list of image file paths from the specified recommendation folder.
    Returns a list of full image paths.
    Includes debug prints (can be removed for final app).
    """
    image_paths = []
    # Use the dictionary keys directly for lookup
    arch_type_key = arch_type_dict_key
    footwear_category_key = footwear_category_dict_key

    # print(f"\nDEBUG: Entering get_recommended_image_paths function") # Can remove
    # print(f"DEBUG: Input arch type key: {arch_type_key}, Input category key: {footwear_category_key}") # Can remove


    # Use the dictionary to get the folder path
    folder_path = rec_image_folders_dict.get(arch_type_key, {}).get(footwear_category_key, None)


    # print(f"DEBUG: Resolved folder path from dictionary: {folder_path}") # Can remove

    if folder_path and os.path.isdir(folder_path): # Check if path is valid AND a directory
        # print(f"DEBUG: Path is a directory.") # Can remove
        try:
            all_files = os.listdir(folder_path)
            # print(f"DEBUG: os.listdir found {len(all_files)} items in {folder_path}.") # Can remove


            image_extensions = ('.png', '.jpg', '.jpeg', '.gif', '.bmp')
            # Ensure filenames are treated case-insensitively for extensions and are strings
            image_files = [f for f in all_files if isinstance(f, str) and f.lower().endswith(image_extensions)]

            # print(f"DEBUG: Image files found AFTER FILTERING: {image_files}") # Can remove


            # Create full paths
            image_paths = [os.path.join(folder_path, f) for f in image_files]

        except Exception as e:
            st.error(f"Error listing contents of {folder_path}: {e}") # Use st.error for Streamlit
            image_paths = []
    elif folder_path: # Path was defined in dict but not found or not a directory
         st.warning(f"Recommended image folder defined but not found or is not a directory: {folder_path}") # Use st.warning for Streamlit
    else: # Path was not defined in the dictionary (mapping issue)
         # This case should ideally be caught by the mapping logic before calling this function
         # print(f"DEBUG: Folder path not resolved from dictionary for keys: ['{arch_type_key}']['{footwear_category_key}']") # Can remove
         pass # Do nothing, mapping error should be handled before


    # print(f"DEBUG: Exiting get_recommended_image_paths function. Returning {len(image_paths)} paths.") # Can remove
    return image_paths


# --- Helper Function for Image Prediction (Adapted from Colab) ---
# No caching here as prediction happens per upload
def preprocess_and_predict_arch(image_file, arch_model, img_height, img_width, class_names_arch):
    """
    Loads, preprocesses an image file, and predicts arch type using the model.
    Returns the predicted arch type and an error message (if any).
    """
    if arch_model is None:
        return None, "Arch type model is not loaded."

    predicted_arch_type = None
    error_message = None

    try:
        # Use PIL to open and resize the image
        img = Image.open(image_file).resize((img_width, img_height))
        img_array = np.array(img) # Convert PIL image to numpy array

        # Ensure image is RGB (handle potential grayscale or RGBA)
        if img_array.ndim == 2: # Grayscale
             img_array = np.stack((img_array,)*3, axis=-1)
        elif img_array.shape[-1] == 4: # RGBA
             img_array = img_array[..., :3]


        img_array = np.expand_dims(img_array, axis=0) # Create a batch
        img_array = img_array.astype('float32') / 255.0 # Rescale the image

        # Make the prediction
        predictions = arch_model.predict(img_array, verbose=0) # Use verbose=0 to suppress prediction output
        predicted_class_index = np.argmax(predictions)

        # Ensure the predicted class index is within the bounds of class_names_arch
        if 'class_names_arch' in globals() and class_names_arch and 0 <= predicted_class_index < len(class_names_arch):
            predicted_arch_type = class_names_arch[predicted_class_index]
        else:
            error_message = f"Warning: Predicted class index {predicted_class_index} is out of bounds or class names not available."
            predicted_arch_type = "Unknown" # Set to unknown on error

        return predicted_arch_type, error_message

    except Exception as e:
        return None, f"Error during image processing or prediction: {e}"

# --- Helper Function for Questionnaire Recommendation Logic (Adapted from Colab) ---
# No caching here as recommendation logic depends on user input
def determine_questionnaire_recommendation_categories(user_arch_type_display, intended_use_display, user_terrain_display, num_runs_per_week, user_height, user_weight, rec_image_folders_dict):
    """
    Determines potential recommendation category keys based on questionnaire answers.
    Returns a list of (first_level_dict_key, second_level_dict_key) tuples that *could* apply.
    The actual fetching happens later.
    """
    potential_category_keys_list = [] # List to store potential (first_level_dict_key, second_level_dict_key) tuples

    # Map user's perceived arch type (display name) to the correct FIRST LEVEL dictionary key (e.g., 'Flat' -> 'flat footwear')
    # This mapping must match the top-level keys in your recommended_image_folders dictionary
    # first_level_dict_key_map = { ... } # Defined globally now

    # Use lowercase of display value for lookup in the global map
    first_level_dict_key_q = first_level_dict_key_map.get(user_arch_type_display.lower(), None)


    # Map user's intended use and perceived arch to the correct SECOND LEVEL dictionary category keys
    # This mapping must align with the structure of your recommended_image_folders dictionary keys (e.g., 'shoes', 'sandal/slipper', 'formal shoes')

    if first_level_dict_key_q and first_level_dict_key_q in rec_image_folders_dict: # Ensure the first level key is valid and exists

         arch_dict = rec_image_folders_dict[first_level_dict_key_q]

         if intended_use_display.lower() == 'running':
              # Logic for Running - Suggest ONLY Shoes based on arch type
              for key in arch_dict:
                   if 'shoes' in key.lower(): # Find the key containing 'shoes'
                        potential_category_keys_list.append((first_level_dict_key_q, key))
                        break # Assume only one 'shoes' category needed for running

         elif intended_use_display.lower() == 'general':
              # Logic for General Purpose - Suggest Shoes, Sandal/Slipper, Formal Shoes based on arch type
              # We don't fetch images here, just determine the potential categories based on arch
              for key in arch_dict:
                   if 'shoes' in key.lower(): # Find the key containing 'shoes'
                       potential_category_keys_list.append((first_level_dict_key_q, key))
                   if 'slipper' in key.lower() or 'sandal' in key.lower(): # Find key containing 'slipper' or 'sandal'
                        potential_category_keys_list.append((first_level_dict_key_q, key))
                   if 'formal' in key.lower(): # Find key containing 'formal'
                        potential_category_keys_list.append((first_level_dict_key_q, key))

              # You could add more complex logic based on height/weight or other factors here
              # For example, if user_height/user_weight indicates larger build, maybe recommend more robust footwear -> try finding a key containing 'boots'


         # Ensure no duplicate (first_level_dict_key, second_level_dict_key) tuples are added
         # Convert list to set then back to list to remove duplicates
         potential_category_keys_list = list(set(potential_category_keys_list))


         # print(f"DEBUG: Determined potential recommendation category key tuples: {potential_category_keys_list}") # Can remove


    else:
         st.warning(f"Perceived arch type '{user_arch_type_display}' could not be mapped to a valid recommendation category key in app.py.")


    return potential_category_keys_list


# --- Streamlit App Interface ---

# Set the title of the Streamlit application
st.title("SoleSmart: Intelligent Footwear Recommendation System")

# Add the tagline below the title
st.markdown("_“The Science Behind Every Step.”_") # Added the tagline in italics


# --- Add Custom CSS for Styling (Optional) ---
# Create a 'style.css' file in the same directory as app.py
# with your CSS rules (e.g., for light green background and black text)
# Then uncomment and use the function below:

def local_css(file_name):
    """Loads and applies custom CSS from a local file."""
    try:
        with open(file_name) as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.sidebar.warning(f"Could not find {file_name}. Make sure it's in the same directory as app.py") # Use sidebar
    except Exception as e:
         st.sidebar.error(f"Error loading CSS file {file_name}: {e}") # Use sidebar

# Call the function to apply the CSS (uncomment if you have style.css)
local_css("style.css") # UNCOMMENTED THIS LINE


st.sidebar.title("Choose Recommendation Method")
recommendation_method = st.sidebar.radio(
    "Select a method:",
    ("Image Analysis", "Questionnaire")
)

# --- Image Analysis Section ---
if recommendation_method == "Image Analysis":
    st.header("Analyze Footwear Image")

    st.write("Upload an image of a foot to get its arch type prediction and then see footwear recommendations.")

    # Image Upload
    uploaded_file = st.file_uploader("Choose a foot image...", type=["jpg", "jpeg", "png"])

    if uploaded_file is not None:
        # Display the uploaded image
        # Use use_container_width instead of use_column_width
        image_display = Image.open(uploaded_file)
        st.image(image_display, caption="Uploaded Image", use_container_width=True)

        # Make prediction when file is uploaded
        # Reset the file pointer to the beginning for the prediction function
        uploaded_file.seek(0)

        st.subheader("Image Analysis Results:")
        if loaded_model_arch_type:
            predicted_arch_type, prediction_error = preprocess_and_predict_arch(
                uploaded_file,
                loaded_model_arch_type,
                img_height,
                img_width,
                class_names_arch
            )

            if prediction_error:
                st.error(f"Prediction Error: {prediction_error}")
                predicted_arch_type = None # Ensure arch type is None on error
            elif predicted_arch_type:
                st.write(f"Predicted Foot Arch Type: **{predicted_arch_type}**")


            # --- Get User Choice for Footwear Category & Display Recommendations (Streamlit Widgets) ---
            # Only show category selection if arch type was predicted and recommended data dictionary is built
            if predicted_arch_type and recommended_image_folders:
                st.subheader("Get Image-Based Recommendation:")
                st.write(f"Based on the predicted arch type ({predicted_arch_type}), what type of footwear are you looking for?")

                # Define category options for the selectbox display (User-friendly names)
                category_options_display = ['Select Category', 'Shoes', 'Sandal/Slipper', 'Formal Shoes'] # Adjust these as needed

                selected_category_display = st.selectbox(
                    "Select Footwear Category:",
                    category_options_display
                )

                if selected_category_display != 'Select Category':
                    # Map display name (lowercase) to standard category key (lowercase)
                    # standard_category_map = { ... } # Defined globally now
                    standard_category_key = standard_category_map.get(selected_category_display.lower(), None)


                    if predicted_arch_type and standard_category_key:
                         # Map Predicted Arch Type (lowercase) to the correct FIRST LEVEL dictionary key (e.g., 'flat' -> 'flat footwear')
                         # first_level_dict_key_map = { ... } # Defined globally now
                         predicted_arch_type_lower = predicted_arch_type.lower()
                         first_level_dict_key = first_level_dict_key_map.get(predicted_arch_type_lower, None)


                         # Map Predicted Arch Type (lowercase) and Standard Category Key (lowercase) to the ACTUAL SECOND LEVEL Dictionary Key
                         # **Ensure this mapping matches the ACTUAL keys in your recommended_image_folders dictionary's second level**
                         # specific_dictionary_key_map_image_analysis = { ... } # Defined globally now

                         # Look up the actual dictionary key using the first level key and the standard category key
                         second_level_dict_key = None
                         if first_level_dict_key in recommended_image_folders:
                              for key in recommended_image_folders[first_level_dict_key]:
                                   if standard_category_key in key.lower(): # Check if standard key is in the dictionary key
                                        second_level_dict_key = key
                                        break # Found the key


                         # Check if both levels of keys exist in the recommended_image_folders dictionary structure
                         if first_level_dict_key and second_level_dict_key and \
                            first_level_dict_key in recommended_image_folders and \
                            second_level_dict_key in recommended_image_folders[first_level_dict_key]:

                             # Get recommended image paths based on the resolved dictionary keys
                             recommended_image_paths = get_recommended_image_paths(
                                 first_level_dict_key, # Use the first level dictionary key
                                 second_level_dict_key, # Use the second level dictionary key
                                 recommended_image_folders # Pass the dictionary
                             )

                             if recommended_image_paths:
                                 st.subheader("Recommended Footwear Images:")
                                 # Limit the number of images to display (e.g., first 10)
                                 images_to_display_limited = recommended_image_paths[:10] # Take the first 10 images

                                 # Display images in columns
                                 cols_per_row = 5
                                 # num_rows = (len(images_to_display_limited) + cols_per_row - 1) // cols_per_row # Not strictly needed for layout


                                 # Create columns outside the loop for better layout control
                                 # Adjust the number of columns if you display fewer than 5 images
                                 num_cols_to_create = min(len(images_to_display_limited), cols_per_row)
                                 if num_cols_to_create > 0:
                                      columns = st.columns(num_cols_to_create)
                                 else:
                                      columns = [] # Empty list if no images to display


                                 for i, img_path in enumerate(images_to_display_limited):
                                      # Determine which column to place the image in
                                      col_index = i % cols_per_row # Use modulo with cols_per_row for wrapping
                                      # Ensure col_index is valid for the number of columns created
                                      if col_index < num_cols_to_create:
                                           with columns[col_index]: # Place image in the determined column
                                               try:
                                                   img = Image.open(img_path)
                                                   st.image(img, caption=os.path.basename(img_path).split('.')[0].replace('_', ' '), use_container_width=True)
                                               except FileNotFoundError:
                                                    st.warning(f"Recommended image file not found: {img_path}")
                                               except Exception as e:
                                                    st.error(f"Could not load image {img_path}: {e}")
                                      # else: # Should not happen with correct col_index logic
                                           # print(f"DEBUG: col_index {col_index} out of bounds for {num_cols_to_create} columns.")


                             else:
                                  st.info(f"No recommended images found for {predicted_arch_type} arches and {selected_category_display} in the specified folder.")

                         else:
                             # This error indicates a mapping mismatch in app.py
                             st.error(f"Internal Mapping Error: Dictionary key combination ['{first_level_dict_key}']['{second_level_dict_key}'] not found in recommended_image_folders dictionary definition in app.py.")


                    elif selected_category_display.lower() != 'select category':
                         st.warning(f"Could not map selected category '{selected_category_display}' to a standard category key.")

            elif predicted_arch_type: # If arch type predicted, but no category selected yet
                 st.info("Please select a footwear category from the dropdown.")


            # If arch prediction failed or model not loaded, error messages are already handled
            # pass


        else:
            st.warning("Arch type model not available. Please ensure the model file is correctly placed and loaded.")
            # Optionally, suggest using the Questionnaire method

# --- Questionnaire Section ---
elif recommendation_method == "Questionnaire":
    st.header("Footwear Recommendation Questionnaire")

    st.write("Answer the questions below to get a personalized recommendation.")

    if recommended_image_folders: # Only show questionnaire if recommended image data dictionary is built

        # --- Questionnaire Inputs (Streamlit Widgets) ---
        # Perceived Arch Type
        user_arch_type_display = st.selectbox(
            "What is your perceived arch type?",
            ('Select One', 'Flat', 'Normal', 'High'),
            key='q_arch_type' # Add a unique key for session state
        )

        # Intended Use (Running or General Purpose)
        intended_use_display = st.selectbox(
            "Is the recommendation for Running or General Purpose?",
            ('Select One', 'Running', 'General'),
            key='q_intended_use' # Add a unique key for session state
        )

        # Running specific questions (only show if intended_use is 'Running')
        user_terrain_display = None
        num_runs_per_week = None
        if intended_use_display == 'Running':
            user_terrain_display = st.selectbox(
                "What type of terrain do you usually run on?",
                ('Select One', 'Road', 'Trail', 'Track', 'Mixed'),
                key='q_terrain' # Add a unique key for session state
            )
            num_runs_per_week = st.text_input("How many times per week do you typically run? (Enter a number)", key='q_frequency') # Add a unique key

        # Add other general preference questions here if needed (e.g., climate, comfort)
        user_height = st.text_input("Enter your height (e.g., 175 cm or 5'9'')", key='q_height') # Add a unique key
        user_weight = st.text_input("Enter your weight (e.g., 70 kg or 155 lbs)", key='q_weight') # Add a unique key


        # --- Get Recommendation Button (Questionnaire) ---
        # Use st.session_state to manage button click state
        if 'questionnaire_submitted' not in st.session_state:
            st.session_state.questionnaire_submitted = False

        # Add a state variable to track if the General category dropdown should be shown
        if 'show_general_category_dropdown' not in st.session_state:
             st.session_state.show_general_category_dropdown = False

        # Add state variables to store answers after button click
        # Initialize or clear answers when the method changes or app starts
        if 'q_answers' not in st.session_state or st.session_state.get('current_method') != recommendation_method:
             st.session_state.q_answers = {}
             st.session_state.questionnaire_submitted = False
             st.session_state.show_general_category_dropdown = False
             st.session_state.current_method = recommendation_method # Track the current method
             st.session_state.q_general_category = 'Select Category' # Reset general category dropdown state


        if st.button("Get Recommendation"):
             # Validate essential inputs before proceeding
            if user_arch_type_display == 'Select One' or intended_use_display == 'Select One':
                st.warning("Please select your perceived arch type and intended use.")
                st.session_state.questionnaire_submitted = False # Don't submit if validation fails
                st.session_state.show_general_category_dropdown = False # Hide dropdown
            elif intended_use_display == 'Running' and user_terrain_display == 'Select One':
                 st.warning("Please select your terrain preference for running.")
                 st.session_state.questionnaire_submitted = False # Don't submit if validation fails
                 st.session_state.show_general_category_dropdown = False # Hide dropdown
            else:
                # Store current answers in session state for use after rerun
                st.session_state.q_answers = {
                     'arch_type': user_arch_type_display,
                     'intended_use': intended_use_display,
                     'terrain': user_terrain_display,
                     'frequency': num_runs_per_week,
                     'height': user_height,
                     'weight': user_weight
                }
                st.session_state.questionnaire_submitted = True # Mark questionnaire as submitted

                # Determine if the General category dropdown should be shown on the next rerun
                if intended_use_display == 'General':
                     st.session_state.show_general_category_dropdown = True
                else:
                     st.session_state.show_general_category_dropdown = False # Hide dropdown for Running
                     st.session_state.q_general_category = 'Select Category' # Reset dropdown value if not showing

                # Rerun the app to show the next step based on state
                st.rerun()


        # --- Display Recommendations or Next Step based on State and Intended Use ---
        if st.session_state.questionnaire_submitted:
             # Retrieve stored answers
             user_arch_type_display = st.session_state.q_answers.get('arch_type', 'Select One')
             intended_use_display = st.session_state.q_answers.get('intended_use', 'Select One')
             user_terrain_display = st.session_state.q_answers.get('terrain', None)
             num_runs_per_week = st.session_state.q_answers.get('frequency', None)
             user_height = st.session_state.q_answers.get('height', None)
             user_weight = st.session_state.q_answers.get('weight', None)


             st.subheader("Recommendation Results:")

             # Logic for Running - Determine and display recommendations immediately
             if intended_use_display == 'Running':
                 st.write("Generating recommendation for Running...")
                 # Determine potential recommendation categories based on inputs
                 recommended_categories_keys_list = determine_questionnaire_recommendation_categories(
                     user_arch_type_display,
                     intended_use_display, # Will be 'Running'
                     user_terrain_display,
                     num_runs_per_week,
                     user_height,
                     user_weight,
                     recommended_image_folders
                 )

                 # Fetch and display images for the determined categories (should only be 'shoes' for running)
                 if recommended_categories_keys_list:
                      all_recommended_images_to_display = []
                      for first_level_key, second_level_key in recommended_categories_keys_list:
                          # Check if both keys exist in the dictionary before calling get_recommended_image_paths
                           if first_level_key in recommended_image_folders and second_level_key in recommended_image_folders.get(first_level_key, {}):
                               image_paths = get_recommended_image_paths(first_level_key, second_level_key, recommended_image_folders)
                               all_recommended_images_to_display.extend(image_paths)
                           else:
                                st.warning(f"Recommendation category not found for arch type '{user_arch_type_display}' and category key '{second_level_key}'. Please check app.py dictionary mappings.")


                      if all_recommended_images_to_display:
                          # Limit and display images
                          images_to_display_limited = all_recommended_images_to_display[:10]
                          cols_per_row = 5
                          num_cols_to_create = min(len(images_to_display_limited), cols_per_row)
                          if num_cols_to_create > 0:
                              columns = st.columns(num_cols_to_create)
                              for i, img_path in enumerate(images_to_display_limited):
                                   col_index = i % cols_per_row
                                   if col_index < num_cols_to_create:
                                        with columns[col_index]:
                                            try:
                                                img = Image.open(img_path)
                                                st.image(img, caption=os.path.basename(img_path).split('.')[0].replace('_', ' '), use_container_width=True)
                                            except FileNotFoundError:
                                                 st.warning(f"Recommended image file not found: {img_path}")
                                            except Exception as e:
                                                 st.error(f"Could not load image {img_path}: {e}")
                          else:
                              st.info("No recommended images found based on your selected options (after checking folders).")

                      else:
                           st.info("No recommended images found based on your running input (no valid folders/keys found).")

                 else:
                      st.info("No recommendation categories determined based on your running input.")


             # Logic for General Purpose - Show category dropdown first if state variable is True
             elif intended_use_display == 'General' and st.session_state.show_general_category_dropdown:
                 st.write("Please select a specific footwear category for General Use:")

                 # Define category options for the second dropdown (User-friendly names)
                 general_category_options = ['Select Category', 'Shoes', 'Sandal/Slipper', 'Formal Shoes'] # Adjust as needed

                 selected_general_category = st.selectbox(
                     "Select Footwear Type:",
                     general_category_options,
                     key='q_general_category' # Use a unique key
                 )

                 # --- Display recommendations ONLY after a category is selected in the second dropdown ---
                 if selected_general_category != 'Select Category':
                      st.write(f"Generating recommendation for General Use: {selected_general_category}...")

                      # Determine the specific dictionary key based on Perceived Arch and selected General Category
                      # first_level_dict_key_map is defined globally

                      # Map selected General Category (lowercase) to its standard internal key
                      # standard_category_map is defined globally
                      standard_category_key_general = standard_category_map.get(selected_general_category.lower(), None)


                      if user_arch_type_display and standard_category_key_general:
                           # Look up the actual dictionary key using the first level key and the standard category key
                           # first_level_dict_key_map is defined globally
                           first_level_dict_key_q = first_level_dict_key_map.get(user_arch_type_display.lower(), None)

                           # Find the second level key in recommended_image_folders based on the standard_category_key_general
                           # specific_dictionary_key_map_general is not needed if we just look up in the dictionary directly
                           second_level_dict_key_general = None
                           if first_level_dict_key_q in recommended_image_folders:
                                for key in recommended_image_folders[first_level_dict_key_q]:
                                     # Check if standard key is in the dictionary key (case-insensitive)
                                     if standard_category_key_general and standard_category_key_general.lower() in key.lower():
                                          second_level_dict_key_general = key
                                          break # Found the key


                           if first_level_dict_key_q and second_level_dict_key_general:
                                # Check if both levels of keys exist in the recommended_image_folders structure (redundant check, but safe)
                                if first_level_dict_key_q in recommended_image_folders and second_level_dict_key_general in recommended_image_folders[first_level_dict_key_q]:
                                    # Get recommended image paths based on the resolved dictionary keys
                                    recommended_image_paths = get_recommended_image_paths(
                                        first_level_dict_key_q, # Use the first level dictionary key (e.g., 'flat footwear')
                                        second_level_dict_key_general, # Use the second level dictionary key (e.g., 'shoes')
                                        recommended_image_folders # Pass the dictionary
                                    )

                                    if recommended_image_paths:
                                         st.subheader("Recommended Footwear Images:")
                                         # Limit the number of images to display (e.g., first 10)
                                         images_to_display_limited = recommended_image_paths[:10] # Take the first 10 images

                                         # Display images in columns
                                         cols_per_row = 5
                                         num_cols_to_create = min(len(images_to_display_limited), cols_per_row)
                                         if num_cols_to_create > 0:
                                              columns = st.columns(num_cols_to_create)
                                              for i, img_path in enumerate(images_to_display_limited):
                                                   col_index = i % cols_per_row
                                                   if col_index < num_cols_to_create:
                                                        with columns[col_index]:
                                                            try:
                                                                img = Image.open(img_path)
                                                                st.image(img, caption=os.path.basename(img_path).split('.')[0].replace('_', ' '), use_container_width=True)
                                                            except FileNotFoundError:
                                                                 st.warning(f"Recommended image file not found: {img_path}")
                                                            except Exception as e:
                                                                 st.error(f"Could not load image {img_path}: {e}")
                                         else:
                                              st.info("No recommended images found based on your selected options (after checking folders).")

                                    else:
                                         st.info("No recommended images found based on your selected options (no valid folders/keys found).")

                                else:
                                     st.error(f"Internal Mapping Error: Dictionary key combination ['{first_level_dict_key_q}']['{second_level_dict_key_general}'] not found in recommended_image_folders dictionary definition in app.py.")


                           else:
                                st.warning(f"Could not map perceived arch '{user_arch_type_display}' and selected category '{selected_general_category}' to a specific dictionary key.")

                      elif selected_general_category.lower() != 'select category':
                          st.warning(f"Could not map selected category '{selected_general_category}' to a standard category key.")


             # If intended_use was Select One (should be caught by validation, but as a fallback)
             # or if intended_use was General but show_general_category_dropdown is False (shouldn't happen if button logic is correct)
             # else: pass # Do nothing, already handled or waiting for dropdown selection


    else:
        st.warning("Recommended image data not available. Please check the base path in app.py and ensure the folder exists.")